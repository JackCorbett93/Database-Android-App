package com.example.n00153357.ca2_jackcorbett;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

import java.net.URI;

public class MainActivity extends AppCompatActivity {

    TextView output;
    final String WEB_SERVICE_URL = "http://10.0.2.2/cars/Cars.xml";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);



        setContentView(R.layout.activity_main);

        output = (TextView) findViewById(R.id.output);
        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
    }

    public void runClickHandler(View view) {
//        output.append("Button clicked \n");
        MyAsyncTask task = new MyAsyncTask();

        task.execute();

    }

    public void clearClickHandler(View view){
        output.setText( " ");
    }

    private class MyAsyncTask extends AsyncTask<String, String, String> {
        @Override
        protected String doInBackground(String... strings) {
           return HttpManager.getData(WEB_SERVICE_URL);
        }



//        @Override
//        protected void onProgressUpdate(String... values) {
//            super.onProgressUpdate(values);
//            output.append(values[0] + "\n");
//        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            updateDisplay("Starting Task");
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            updateDisplay(result);
//            throw new RuntimeException("This is a question 5");
        }
    }

    public void updateDisplay (String message) {
        output.append(message + "\n");
    }

}